exports.users = [
    {
      id: 1,
      name: "Anna",
      age: 24,
      gender: "kobieta",
      location: "Warszawa"
    },
    {
      id: 2,
      name: "Piotr",
      age: 32,
      gender: "mÄĹźczyzna",
      location: "KrakĂłw"
    },
    {
      id: 3,
      name: "Kasia",
      age: 28,
      gender: "kobieta",
      location: "WrocĹaw"
    },
    {
      id: 4,
      name: "Tomasz",
      age: 45,
      gender: "mÄĹźczyzna",
      location: "PoznaĹ"
    },
    {
      id: 5,
      name: "Magda",
      age: 30,
      gender: "kobieta",
      location: "GdaĹsk"
    },
    {
      id: 6,
      name: "Marcin",
      age: 35,
      gender: "mÄĹźczyzna",
      location: "Katowice"
    },
    {
      id: 7,
      name: "Monika",
      age: 27,
      gender: "kobieta",
      location: "Szczecin"
    },
    {
      id: 8,
      name: "Adam",
      age: 29,
      gender: "mÄĹźczyzna",
      location: "ĹĂłdĹş"
    },
    {
      id: 9,
      name: "Aleksandra",
      age: 26,
      gender: "kobieta",
      location: "PoznaĹ"
    },
    {
      id: 10,
      name: "Bartosz",
      age: 31,
      gender: "mÄĹźczyzna",
      location: "KrakĂłw"
    },
    {
      id: 11,
      name: "Karolina",
      age: 24,
      gender: "kobieta",
      location: "WrocĹaw"
    }
  ]